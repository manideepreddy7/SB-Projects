package com.employee.employeedetails.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.employee.employeedetails.model.Employee;
import com.employee.employeedetails.model.Employeejoin;
import com.employee.employeedetails.model.Organization;

@Repository
public interface empRepo extends JpaRepository<Employee, Integer> {

	@Query(value = "select * from employee  where exp>=:EMPexp", nativeQuery = true)
	public List<Employee> getByExperience(@Param("EMPexp") double EMPexp);
	
	@Query(value = "select e.eid,e.ename,e.exp,e.sal,e.cname,o.cname,o.emp_count,o.city from organization o join employee e on o.c_name=e.cname where o.emp_count>400", nativeQuery = true)
	public List<Organization> joinEmpOrganization();
}
