package com.employee.employeedetails.model;

public class Employeejoin {

	int eid;
	String ename;
	String cname;
	int empcount;
	String city;
	
}
