package com.employee.employeedetails;

import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

	public String emp() {
		Employee emp = new Employee();
		emp.setEid(511);
		emp.setEname("Surya");
		emp.setSal(1000000);
		return emp.toString();
	}
	
	
}
