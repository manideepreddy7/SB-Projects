package com.employee.employeedetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeedetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeedetailsApplication.class, args);
		System.out.println("Hello");
	}

}
