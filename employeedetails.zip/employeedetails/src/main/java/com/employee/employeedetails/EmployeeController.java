package com.employee.employeedetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeService es;
	
	@GetMapping("/details")
	public String EmployeeDetails() {
		return es.emp();
		
		//return "Employee Details Fetched";
	}
	
	@PostMapping("/save")
    public ResponseEntity<String> createUser(@RequestBody Employee emp) {
        // Here you would save the user to the database (omitted for simplicity)
        return ResponseEntity.ok("Employee " +emp.getEname() + " created successfully!");
	
	}
	
}
